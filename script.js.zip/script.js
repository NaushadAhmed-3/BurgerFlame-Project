// Simple JavaScript for Burger Flame Website

let cart = [];
let cartTotal = 0;

// Start countdown timer
function startTimer() {
    let hours = 2;
    let minutes = 30;
    let seconds = 45;
    
    const timer = setInterval(() => {
        seconds--;
        
        if (seconds < 0) {
            seconds = 59;
            minutes--;
            
            if (minutes < 0) {
                minutes = 59;
                hours--;
                
                if (hours < 0) {
                    clearInterval(timer);
                    document.querySelector('.discount-box h3').textContent = 'OFFER EXPIRED';
                    return;
                }
            }
        }
        
        // Update display
        document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
        document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
        document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
    }, 1000);
}

// Flip card function
function flipCard(card) {
    card.parentElement.querySelector('.flip-card').classList.toggle('flipped');
}

// Filter menu items
// Filter menu items (Handles both clicks and auto-load)
function filterCategory(category) {
    // 1. Remove 'active' class from all filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // 2. Add 'active' class to the correct button
    // Check if this is a user click (event exists) or auto-load
    if (typeof event !== 'undefined' && event.type === 'click') {
        event.target.classList.add('active');
    } else {
        // If loaded automatically, find the button by its onclick name
        const autoBtn = document.querySelector(`button[onclick="filterCategory('${category}')"]`);
        if (autoBtn) {
            autoBtn.classList.add('active');
        }
    }

    // 3. Show/hide the actual menu items
    document.querySelectorAll('.menu-item').forEach(item => {
        if (category === 'all' || item.classList.contains(category)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

// Add item to cart
function addToCart(itemName, price) {
    // Check if item already exists
    let found = false;
    
    for (let i = 0; i < cart.length; i++) {
        if (cart[i].name === itemName) {
            cart[i].quantity++;
            found = true;
            break;
        }
    }
    
    if (!found) {
        cart.push({
            name: itemName,
            price: price,
            quantity: 1
        });
    }
    
    // Update cart display
    updateCart();
    
    // Show notification
    alert(`${itemName} added to cart!`);
}

// Update cart display
function updateCart() {
    const cartItems = document.querySelector('.cart-items');
    const cartCount = document.getElementById('cartCount');
    const totalPrice = document.getElementById('totalPrice');
    
    // Clear current items
    cartItems.innerHTML = '';
    
    // Reset total
    cartTotal = 0;
    
    // If cart is empty
    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
        cartCount.textContent = '0';
        totalPrice.textContent = 'Rs.0';
        return;
    }
    
    // Add each item
    cart.forEach((item, index) => {
        const itemElement = document.createElement('div');
        itemElement.className = 'cart-item';
        itemElement.innerHTML = `
            <div>
                <h4>${item.name}</h4>
                <p>Rs.${item.price.toFixed(2)}</p>
            </div>
            <div class="cart-item-controls">
                <button onclick="updateQuantity(${index}, -1)">-</button>
                <span>${item.quantity}</span>
                <button onclick="updateQuantity(${index}, 1)">+</button>
                <button onclick="removeFromCart(${index})">×</button>
            </div>
        `;
        cartItems.appendChild(itemElement);
        
        cartTotal += item.price * item.quantity;
    });
    
    // Update totals
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    totalPrice.textContent = `Rs.${cartTotal.toFixed(2)}`;
}

// Update item quantity
function updateQuantity(index, change) {
    cart[index].quantity += change;
    
    if (cart[index].quantity <= 0) {
        cart.splice(index, 1);
    }
    
    updateCart();
}

// Remove item from cart
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
    alert('Item removed from cart');
}

// Show cart
function showCart() {
    document.querySelector('.cart-sidebar').classList.add('show');
}

// Hide cart
function hideCart() {
    document.querySelector('.cart-sidebar').classList.remove('show');
}

// Checkout
function checkout() {
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }
    
    let orderDetails = 'Order Summary:\n\n';
    
    cart.forEach(item => {
        orderDetails += `${item.name} x${item.quantity} - Rs.${(item.price * item.quantity).toFixed(2)}\n`;
    });
    
    orderDetails += `\nTotal: Rs.${cartTotal.toFixed(2)}\n\n`;
    orderDetails += 'Thank you for your order!';
    
    alert(orderDetails);
    
    // Clear cart
    cart = [];
    updateCart();
    hideCart();
}

// Order now
function orderNow() {
    showCart();
}

// Send message form
function sendMessage(event) {
    event.preventDefault();
    const name = event.target.querySelector('input[type="text"]').value;
    alert(`Thank you ${name}! Your message has been sent.`);
    event.target.reset();
}
// Fries Size add to cart Function
function addFriesToCart() {
    const selector = document.getElementById('friesSize');
    const selectedOption = selector.options[selector.selectedIndex];
    
    const size = selector.value;
    const price = parseFloat(selectedOption.getAttribute('data-price'));
    
    // Calls your existing addToCart function with the specific details
    addToCart(`French Fries (${size})`, price);
}
//Animal Fries Size add to cart Function
function addAnimalFriesToCart() {
    const selection = document.getElementById('AnimalfriesSize');
    const selectedOptions = selection.options[selection.selectedIndex];
    
    const size = selection.value;
    const price = parseFloat(selectedOptions.getAttribute('data-price'));
    
    // Calls your existing addToCart function with the specific details
    addToCart(`Animal Loaded Fries (${size})`, price);
}
// Drinks size and flavour add to cart function
function addCustomDrinkToCart() {
    // 1. Get Flavor
    const flavorSelector = document.getElementById('drinkFlavor');
    const flavor = flavorSelector.value;

    // 2. Get Size and Price
    const sizeSelector = document.getElementById('drinkSize');
    const selectedSizeOption = sizeSelector.options[sizeSelector.selectedIndex];
    const size = sizeSelector.value;
    const price = parseFloat(selectedSizeOption.getAttribute('data-price'));
    
    // 3. Combine them and add to cart
    const finalName = `Soft Drink (${flavor}, ${size})`;
    addToCart(finalName, price);
}
// Initialize when page loads
// Initialize when page loads
window.onload = function() {
    // Only run timer if the element exists (Fixes Home vs Menu page errors)
    if(document.getElementById('hours')) {
        startTimer();
    }
    
    // Navigation Logic
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');

            // ONLY prevent default if it is an ID link (starts with #)
            if (targetId.startsWith('#')) {
                e.preventDefault();
                
                const targetSection = document.querySelector(targetId);
                
                // Update active button
                document.querySelectorAll('.nav-btn').forEach(b => {
                    b.classList.remove('active');
                });
                this.classList.add('active');
                
                // Scroll to section
                if (targetSection) {
                    window.scrollTo({
                        top: targetSection.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            }
            // If it's "menu.html", the code skips the if-block 
            // and the browser loads the new page normally.
        });
    });
    
    // Close cart when clicking outside
    document.addEventListener('click', function(e) {
        const cartSidebar = document.querySelector('.cart-sidebar');
        const cartBtn = document.querySelector('.order-btn');
        
        // Check if elements exist before checking contains (Safety check)
        if (cartSidebar && cartBtn) {
            if (cartSidebar.classList.contains('show') && 
                !cartSidebar.contains(e.target) && 
                !cartBtn.contains(e.target)) {
                hideCart();
            }
        }
    });
    filterCategory('deals');
};